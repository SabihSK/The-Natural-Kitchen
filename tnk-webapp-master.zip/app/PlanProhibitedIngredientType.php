<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlanProhibitedIngredientType extends Model
{
    //
}
