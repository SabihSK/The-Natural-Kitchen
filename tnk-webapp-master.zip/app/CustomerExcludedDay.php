<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerExcludedDay extends Model
{
    protected $table = 'customer_excluded_days';

    protected $guarded = [];
}
