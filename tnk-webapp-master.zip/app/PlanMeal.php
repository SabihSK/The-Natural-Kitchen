<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlanMeal extends Model
{
    //
}
