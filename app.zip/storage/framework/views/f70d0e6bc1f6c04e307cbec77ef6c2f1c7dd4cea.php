<footer class="app-footer">
    <div class="site-footer-right">
    Powered by <a href="http://mannai.tech/" style="color: blue"> MannaiTech</a>
    </div>
</footer>
