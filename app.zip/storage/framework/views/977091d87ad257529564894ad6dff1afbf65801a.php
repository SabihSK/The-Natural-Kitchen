<div class="col-md-12 text-center">
    <a href="<?php echo e(route('generate-missing-ids')); ?>" class="btn btn-info btn-lg btn-huge">
        Generate Custom IDs for Customers not having IDs
    </a>
</div>

<style>
    .btn-huge{
        padding-top:20px;
        padding-bottom:20px;
        font-size: 25px;
    }
</style>
