<?php

namespace App\Observers;

use App\User;

class UserObserver
{
    // public function updating(User $user)
    // {
    //     $role = request()->all();

    //     dd($role);
    // }
}
