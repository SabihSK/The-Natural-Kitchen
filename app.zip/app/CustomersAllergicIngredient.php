<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomersAllergicIngredient extends Model
{
    protected $table = 'customers_allergic_ingredients';
}
